import React, { useEffect, useState } from 'react'

const Form = () => {
    const [data,setData]=useState([])
   const [show,setShow]=useState([])
   useEffect(()=>{
console.log(show.First_Name)
   },[])
    const handleFisrtChange = (e) => {
        setData({...data,First_Name: e.target.value, });
      };
      const handleLastChange = (e) => {
        setData({...data,Last_Name: e.target.value });
      };
      const handleEmailChange = (e) => {
        setData({...data,Email: e.target.value });
      };
      const Register = (e) => {
        e.preventDefault();
      
        setShow(data)
        saveLocal(show)
      
      }
      const saveLocal = (show) => {
        localStorage.setItem("First_Name",show.First_Name)
        localStorage.setItem("Last_Name",show.Last_Name)
        localStorage.setItem("Email",show.Email)

      }
     
      
    
  return (
    <>
     <div className='container h-100 row  justify-content-center align-items-center mt-5'>
     <form className='w-50 p-5  bg-dark col-6 offset-6 '>
     <p className='text-white'>{show.First_Name} {show.Last_Name}  {show.Email}</p>
       <input value={data.Fisrt_Name} className='form-control mt-2 ml-5 w-75' type='text' name='Fisrt_Name' placeholder='Enter Fisrt Name' onChange={handleFisrtChange}/>
       <input value={data.Last_Name} className='form-control mt-2 ml-5 w-75' type='text' name='Last_Name' placeholder='Enter Last Name' onChange={handleLastChange}/>
       <input  value={data.Email} className='form-control mt-2  ml-5 w-75' type='email' name='Email' placeholder='Enter Email' onChange={handleEmailChange}/>
       <button className='btn btn-success btn-block mt-2  ml-5 w-75' onClick={Register}>Register</button>

     </form>

     </div> 
    </>
  )
}
export default Form
