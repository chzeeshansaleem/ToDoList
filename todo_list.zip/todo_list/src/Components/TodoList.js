import React, { useEffect, useState } from "react";

const TodoList = () => {
  // hook for holding all the tasks
  const [todos, setTodos] = useState([]);
  // hook for getting the data from input field
  const [newTodo, setNewTodo] = useState("");
  // state variable for holding the task being edited
  const [editingTodo, setEditingTodo] = useState(null);

  useEffect(() => {
    if (localStorage.getItem("tasks")) {
      setTodos(JSON.parse(localStorage.getItem("tasks")));
    }
  }, []);

  // function for storing the data into browser
  const saveData = (newTodos) => {
    localStorage.setItem("tasks", JSON.stringify(newTodos));
  };

  const AddTodo = () => {
    let newTodos = [...todos, { todo: newTodo, id: Date.now() }];
    setTodos(newTodos);
    setNewTodo("");
    saveData(newTodos);
  };

  const delTask = (id) => {
    let newTodos = todos.filter((todo) => todo.id !== id);
    setTodos(newTodos);
    saveData(newTodos);
  };

  const startEditing = (id) => {
    const todoToEdit = todos.find((todo) => todo.id === id);
    setEditingTodo(todoToEdit);
  };

  const cancelEditing = () => {
    setEditingTodo(null);
  };

  const finishEditing = (id, newTodoText) => {
    const newTodos = todos.map((todo) => {
      if (todo.id === id) {
        return { ...todo, todo: newTodoText };
      } else {
        return todo;
      }
    });
    setTodos(newTodos);
    setEditingTodo(null);
    saveData(newTodos);
  };

  return (
    <div className="container">
      <h1 className="text-center display-3">To Do List</h1>
      <input
        type="text"
        className="form-control"
        value={newTodo}
        placeholder="Enter the Task"
        onChange={(e) => setNewTodo(e.target.value)}
      />
      <br />
      <button className="btn btn-primary" onClick={AddTodo}>
        Save Task
      </button>
      <hr />
      <table className="table">
        {todos.map((todo) => (
          <tr key={todo.id}>
            {editingTodo && editingTodo.id === todo.id ? (
              <>
                <td>
                  <input
                    type="text"
                    className="form-control"
                    defaultValue={editingTodo.todo}
                    onChange={(e) =>
                      setEditingTodo({ ...editingTodo, todo: e.target.value })
                    }
                  />
                </td>
                <td>
                  <button
                    className="btn btn-primary btn-sm"
                    onClick={() =>
                      finishEditing(editingTodo.id, editingTodo.todo)
                    }
                  >
                    Save
                  </button>
                </td>
                <td>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={cancelEditing}
                  >
                    Cancel
                  </button>
                </td>
              </>
            ) : (
              <>
                <td>{todo.todo}</td>
                <td>
                  <button
                    className="btn btn-success btn-sm" onClick={() => startEditing(todo.id)}>Edit</button>
                </td>
                <td>
                  <button
                    className="btn btn-danger btn-sm"
                    onClick={() => delTask(todo.id)}
                  >
                    X
                  </button>
                </td>
              </>
            )}
          </tr>
        ))}
      </table>
    </div>
  );
};

export default TodoList;
