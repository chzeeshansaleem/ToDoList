import React, { useEffect, useState } from 'react'

const Tes = () => {
   //hook for holding all the tasks
   const [todos, setTodos] = useState([]);

   //hook for getting the data from input field
   const [newTodo, setNewTodo] = useState();
   // console.log(newTodo);

   //function for storing the data into browser
   const saveData = (newTodos) => {
       localStorage.setItem("tasks", JSON.stringify(newTodos));
   }

   //using the hook useEffect to fetch and show all the data from localStorage
   useEffect(() => {
       if(localStorage.getItem("tasks")){
           setTodos(JSON.parse(localStorage.getItem("tasks")));
       }
   },[])

   const AddTodo = () => {
       let newTodos = [...todos, { todo: newTodo.trim(), id:Date.now() }];
       setTodos(newTodos);
       setNewTodo("");
       console.log(newTodos);
       saveData(newTodos);
   }

   //function for deleting the task
   const delTask = (id) => {
       let newTodos = todos.filter((todo) => todo.id !== id);
       setTodos(newTodos);

       //also deleting the data from localStorage
       saveData(newTodos);
   }
   return (
       <div className='container'>
           <h1 className='text-center display-3'>Enter Your Task</h1>
           <input type="text" className='form-control' value={newTodo} onChange={(e) => setNewTodo(e.target.value)} />
           <br />
           <button className='btn btn-primary' onClick={AddTodo} >Save Task</button>
           <hr />
           <table className='table'>
               <tr>
                   <th>All Tasks</th>
                   <th>Delete</th>
               </tr>
               {
                   todos.map((tod) => (
                       <tr>
                           <td>{tod.todo}</td>
                           <td><button className='btn btn-danger btn-sm' onClick={() => delTask(tod.id)}>X</button></td>
                       </tr>
                   ))
               }
           </table>

       </div>
   )
}

export default Tes
