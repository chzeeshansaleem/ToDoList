import React, { useState } from "react";
import Form from "./Components/Form";
import TodoList from "./Components/TodoList";

const App = () => {
  const [Data, setData] = useState("");

  return (
    <div>
      <TodoList />
      <Form />
    </div>
  );
};

export default App;
